import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.border.LineBorder;

import io.github.dheid.fontchooser.FontDialog;
import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerException;


public class Dashbord extends JFrame 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JLabel lblEraserIcon;
	JEditorPane editorPane;
	FontDialog dialog; 
	
	//music stuff here
	BasicPlayer basicPlayer=new BasicPlayer(); //create player to play music on icon hover

	String erasermusic="eraser.mp3";
	String pathToerasermusic=System.getProperty("user.dir")+"/musics/"+erasermusic;
	private JLabel lblSaveIcon;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	
	
	//database stuff here
	PreparedStatement preparedStatement;
	ResultSet rs;
	
	
	public Dashbord() {
		super("My Dashbord");
		
		getData();
		
		addWindowListener(new WindowAdapter() {
			
			@Override
			public void windowClosing(WindowEvent e) {
				
				//Close connection on the closing event
				try {
				
					//new MainClass();
					AllData.database_obj.connection.close();
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			}
		});
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		setSize(800,600);	
		setResizable(false);
		getContentPane().setLayout(null);
		
		editorPane = new JEditorPane();
		editorPane.setBorder(new LineBorder(Color.BLACK,2,true));
		editorPane.setBounds(0, 0, 525, 561);
		editorPane.setFont(new Font("Tahoma", Font.PLAIN, 14));
		try {
			editorPane.setText(rs.getString(8));
		} catch (SQLException e2) {
			
			e2.printStackTrace();
		}
		getContentPane().add(editorPane);
		
		lblEraserIcon = new JLabel("");

		lblEraserIcon.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseEntered(MouseEvent e) {
				lblEraserIcon.setIcon(new ImageIcon(Dashbord.class.getResource("/images/HoverEraserIcon.png")));
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				lblEraserIcon.setIcon(new ImageIcon(Dashbord.class.getResource("/images/MainEraserIcon.png")));
				try {
					basicPlayer.stop();
				} catch (BasicPlayerException e1) {
					
					e1.printStackTrace();
				}
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				editorPane.selectAll(); 
				editorPane.setSelectedTextColor(Color.red);
				editorPane.setText("");
				
				
			}
			@Override
			public void mousePressed(MouseEvent e) {
				//This code is for  background eraser music when mouse is Pressed on eraser icon
				try {
					 basicPlayer.open(new URL("file:///" + pathToerasermusic));
					 basicPlayer.play();
				}
				catch(Exception e1)
				{
					e1.printStackTrace();
				}
				
			}
		});
		lblEraserIcon.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblEraserIcon.setBackground(Color.MAGENTA);
		lblEraserIcon.setIcon(new ImageIcon(Dashbord.class.getResource("/images/MainEraserIcon.png")));
		lblEraserIcon.setBounds(535, 68, 112, 96);
		getContentPane().add(lblEraserIcon);
		
		
		JLabel lblNewLabel_1 = new JLabel("Welcome :"+AllData.loggedusername);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_1.setBounds(535, 10, 145, 32);
		getContentPane().add(lblNewLabel_1);
		
		lblSaveIcon = new JLabel("");
		lblSaveIcon.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				lblSaveIcon.setIcon(new ImageIcon(Dashbord.class.getResource("/images/SaveHover.png")));
			}
			@Override
			public void mouseExited(MouseEvent e) {
				lblSaveIcon.setIcon(new ImageIcon(Dashbord.class.getResource("/images/SaveMain.png")));
			}
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					
					PreparedStatement preparedStatement=AllData.database_obj.connection.prepareStatement("update users set data=?,lastedit=? where id=?");
					
					//get editor data
					String data=editorPane.getText().toString();
					
					//get current datetime 
					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Date date = new Date();
					
					preparedStatement.setString(1, data);
					preparedStatement.setString(2, dateFormat.format(date));
					preparedStatement.setInt(3,AllData.loggeduserid);
					
					if(!preparedStatement.execute()) 
					{
							System.out.println("Updated");
					}
					else
					{
						System.out.println("Failed to Update");	
					}
				}
				
				catch (SQLException e1)
				{
				
					e1.printStackTrace();
				}
			}
		});
		lblSaveIcon.setIcon(new ImageIcon(Dashbord.class.getResource("/images/SaveMain.png")));
		lblSaveIcon.setBounds(672, 68, 112, 96);
		getContentPane().add(lblSaveIcon);
		
		lblNewLabel = new JLabel("");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				FontDialog.showDialog(editorPane); //set selected Font to editor pane
			}
		});

		lblNewLabel.setIcon(new ImageIcon(Dashbord.class.getResource("/images/Font.png")));
		lblNewLabel.setBounds(535, 223, 91, 78);
		getContentPane().add(lblNewLabel);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				//Set font color
				Color color=JColorChooser.showDialog(editorPane, "Select Color", Color.BLACK);
				editorPane.setForeground(color);
			}
		});
		lblNewLabel_2.setIcon(new ImageIcon(Dashbord.class.getResource("/images/Paint.png")));
		lblNewLabel_2.setBounds(672, 237, 64, 64);
		getContentPane().add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Color c=JColorChooser.showDialog(editorPane, "Select Note Color ", Color.white);
				editorPane.setBackground(c);
			}
		});
		lblNewLabel_3.setIcon(new ImageIcon(Dashbord.class.getResource("/images/Color.png")));
		lblNewLabel_3.setBounds(555, 366, 71, 64);
		getContentPane().add(lblNewLabel_3);
		
		JLabel lblLastUpdate;
		try {
			lblLastUpdate = new JLabel("Last Update:"+rs.getString(7));
			lblLastUpdate.setFont(new Font("Tahoma", Font.PLAIN, 13));
			lblLastUpdate.setBounds(535, 475, 249, 53);
			getContentPane().add(lblLastUpdate);
		} catch (SQLException e1) {
			
			e1.printStackTrace();
		}
	
	
	
		
		//make frame visible to screen
		setVisible(true);
	}
	
	private void getData() {
		try {
			preparedStatement=AllData.database_obj.connection.prepareStatement("Select * from users where id=?");
			preparedStatement.setInt(1, AllData.loggeduserid);
			rs= preparedStatement.executeQuery();
			rs.next(); 
			if(!rs.equals(""))	//if no data found
			{
				System.out.println("Data Found");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
	public static void main(String s[])
	{
		Dashbord obj = new Dashbord();
		obj.setSize(800,600);
		obj.setVisible(true);
		
	}
}
