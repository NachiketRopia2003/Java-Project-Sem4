import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
	Connection connection;

	@SuppressWarnings("deprecation")
	public DB()
	{
		String url="jdbc:mysql://localhost:3306/"; //DB url
		String dbName="notes";								  //Database name
		String driver="com.mysql.cj.jdbc.Driver";					  //java driver
		String username="root";							  //MySql username
		String password="Nishu#2003";							  //MySql password
		try {
			Class.forName(driver).newInstance();
		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		try {
			connection=DriverManager.getConnection(url+dbName,username,password);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
}
