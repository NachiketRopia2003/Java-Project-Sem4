public class AllData {
	//Store logged in user data here as a session so we can access in all frames
	public static String loggedusername="";
	public static int loggeduserid;
	public static DB database_obj=new DB(); //create database object
}
