import java.sql.*;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.URL;
import java.net.URLConnection;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
 
public class MainClass extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtUsername;
	private JTextField txtPassword;
	private JTextField txtRegUname;
	private JTextField txtRegPass;
	private JTextField txtRegConPass;
	
	
	String message=""; 		  // message string for login and registration message
	
	 @SuppressWarnings("unused")
	public MainClass()
	{
		
		 if(AllData.loggeduserid!=0)  
		 {
			 setVisible(false);
			 new Dashbord();
			 
		 }
		 else
			 
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				//Close connection when frame is closing
				try {
					AllData.database_obj.connection.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		//Connect to Database 
		DB db=new DB();
		setSize(908,644);
				
		setResizable(false);
		setTitle("My Notes Application");
		//getContentPane().setV
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		//Create borders for buttons
		LineBorder line = new LineBorder(Color.white,3,true);
		LineBorder borderLoginBox = new LineBorder(Color.WHITE,4,true);
				
		JPanel panel = new JPanel();
		panel.setBackground(new Color(65,33,118));
		panel.setBounds(0, 0, 917, 613);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(85, 267, 261, 49);
		txtUsername.setBorder(new LineBorder(Color.white,2,true));
		txtUsername.setForeground(Color.WHITE);
		txtUsername.setFont(new Font("Tahoma", Font.PLAIN, 30));
		txtUsername.setBackground(new Color(102, 51, 153));
		txtUsername.setText("Username");
		panel.add(txtUsername);
		txtUsername.setColumns(10);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(85, 360, 261, 49);
		txtPassword.setBorder(new LineBorder(Color.white,2,true));
		txtPassword.setText("Password");
		txtPassword.setForeground(Color.WHITE);
		txtPassword.setFont(new Font("Tahoma", Font.PLAIN, 30));
		txtPassword.setColumns(10);
		txtPassword.setBackground(new Color(102, 51, 153));
		panel.add(txtPassword);
		
		JLabel lblNewLabel_1 = new JLabel(" My Notes");
		lblNewLabel_1.setBounds(10, 10, 380, 125);
		lblNewLabel_1.setForeground(new Color(0, 201, 169));
		lblNewLabel_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 55));
		panel.add(lblNewLabel_1);
		lblNewLabel_1.setIcon(new ImageIcon(MainClass.class.getResource("/images/Notes.png")));
		
		JPanel panelLoginBox = new JPanel();
		panelLoginBox.setBounds(25, 166, 391, 377);
		panelLoginBox.setBorder(borderLoginBox);
		panelLoginBox.setBackground(new Color(148, 0, 211));
		panelLoginBox.setForeground(new Color(255, 0, 255));
		panel.add(panelLoginBox);
		panelLoginBox.setLayout(null);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(109, 291, 174, 49);
		panelLoginBox.add(btnLogin);
		btnLogin.setBorder(line);
		btnLogin.setForeground(Color.white);
		btnLogin.setBackground(new Color(0, 201, 169));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(checkInternet())
				{
					String uname=txtUsername.getText().toString();
					String password=txtPassword.getText().toString();
					try {
					
						PreparedStatement preparedStatement=AllData.database_obj.connection.prepareStatement("Select * from users where uname=? and pass=?;");
						preparedStatement.setString(1, uname);
						preparedStatement.setString(2, password);
						
						ResultSet rs= preparedStatement.executeQuery();
						rs.next(); 
						
						if(!rs.equals(""))	 //if login success then set userid and username in Static data for welcoming text in next frame
						{
							AllData.loggeduserid =rs.getInt(1);
							AllData.loggedusername=rs.getString(2);
							
							setVisible(false);
							new Dashbord();
						}
						
					}
					catch(Exception e1)
					{
						message="Please enter valid username or password";
						JOptionPane.showMessageDialog(new JFrame(), message, "Failed to Login",
						        JOptionPane.ERROR_MESSAGE,new ImageIcon(MainClass.class.getResource("images/error.gif")));
					}
				}
			}
		});
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 30));
		
		JLabel lblNewLabel = new JLabel("Login");
		lblNewLabel.setBounds(132, 10, 128, 85);
		panelLoginBox.add(lblNewLabel);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Rockwell", Font.PLAIN, 45));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(482, 134, 357, 435);
		panel.add(panel_2);
		panel_2.setBackground(new Color(148, 0, 211));
		panel_2.setBorder(borderLoginBox);
		panel_2.setLayout(null);
		
		JLabel lblRegistration = new JLabel("Registration");
		lblRegistration.setBounds(48, 10, 338, 85);
		panel_2.add(lblRegistration);
		lblRegistration.setForeground(Color.WHITE);
		lblRegistration.setFont(new Font("Rockwell", Font.PLAIN, 45));
		
		txtRegUname = new JTextField();
		txtRegUname.setBounds(48, 114, 261, 49);
		panel_2.add(txtRegUname);
		txtRegUname.setBorder(new LineBorder(Color.white,2,true));
		txtRegUname.setForeground(Color.WHITE);
		txtRegUname.setFont(new Font("Tahoma", Font.PLAIN, 30));
		txtRegUname.setColumns(10);
		txtRegUname.setBackground(new Color(102, 51, 153));
		
		JLabel lblUsername = new JLabel("Username:");
		lblUsername.setBounds(48, 89, 115, 28);
		panel_2.add(lblUsername);
		lblUsername.setForeground(Color.WHITE);
		lblUsername.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		JLabel labelPassword = new JLabel("Password:");
		labelPassword.setBounds(48, 173, 115, 28);
		panel_2.add(labelPassword);
		labelPassword.setForeground(Color.WHITE);
		labelPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		txtRegPass = new JPasswordField();
		txtRegPass.setBounds(48, 204, 261, 49);
		panel_2.add(txtRegPass);
		txtRegPass.setBorder(new LineBorder(Color.white,2,true));
		txtRegPass.setForeground(Color.WHITE);
		txtRegPass.setFont(new Font("Tahoma", Font.PLAIN, 30));
		txtRegPass.setColumns(10);
		txtRegPass.setBackground(new Color(102, 51, 153));
		
		JLabel labelConPassword = new JLabel("Confirm Password:");
		labelConPassword.setBounds(48, 263, 159, 28);
		panel_2.add(labelConPassword);
		labelConPassword.setForeground(Color.WHITE);
		labelConPassword.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		txtRegConPass = new JPasswordField();
		txtRegConPass.setBounds(48, 287, 261, 49);
		panel_2.add(txtRegConPass);
		txtRegConPass.setBorder(new LineBorder(Color.white,2,true));
		txtRegConPass.setText("");
		txtRegConPass.setForeground(Color.WHITE);
		txtRegConPass.setFont(new Font("Tahoma", Font.PLAIN, 30));
		txtRegConPass.setColumns(10);
		txtRegConPass.setBackground(new Color(102, 51, 153));
		
		JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.setBounds(101, 358, 174, 49);
		panel_2.add(btnSignUp);
		btnSignUp.setBorder(line);
		btnSignUp.setForeground(Color.WHITE);
		btnSignUp.setBackground(new Color(0, 201, 169));
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String uname=txtRegUname.getText().toString();
				String pass=txtRegPass.getText().toString();
				String confirmpass=txtRegConPass.getText().toString();
				
				//if any feilds are empty then show error and don't insert into database
				if(!(uname.equals("") || pass.equals("") || confirmpass.equals("")) )
				{	
					if(!pass.equals(confirmpass))
					{
						message= "Password does't match";
						JOptionPane.showMessageDialog(new JFrame(), message,"Failed",JOptionPane.ERROR_MESSAGE);
					}
					else
					{
						try {
							PreparedStatement preparedStatement=AllData.database_obj.connection.prepareStatement("insert into users (uname,pass,data,bgcolor,fontcolor,font,lastedit) values(?,?,'Welcome to my application,You can save your notes easily and access anytime','','','','')");
							preparedStatement.setString(1, uname);
							preparedStatement.setString(2, pass);
							
							//ResultSet resultSet=preparedStatement.executeQuery();   
								
							//boolean b=preparedStatement.execute();
							if(!preparedStatement.execute())
							{
								message="Account created sucessfully, Now you can login";	
								JOptionPane.showMessageDialog(new JFrame(), message, "Dialog",JOptionPane.INFORMATION_MESSAGE); 
							}
							else
							{
								message= "Something went wrong";
								JOptionPane.showMessageDialog(new JFrame(), message,"Failed",JOptionPane.ERROR_MESSAGE);
							}
							
						} catch (SQLException e1) {
							
							message= "Something went wrong:"+e1.toString();
							JOptionPane.showMessageDialog(new JFrame(), message,"Failed",JOptionPane.ERROR_MESSAGE);
						}
					}
				}
				//if empty then show error message
				else {
					message="username or password should not be empty";
					JOptionPane.showMessageDialog(new JFrame(),message,"Error",JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnSignUp.setFont(new Font("Tahoma", Font.PLAIN, 30));
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBounds(-390, -37, 1307, 686);
		lblNewLabel_2.setIcon(new ImageIcon(MainClass.class.getResource("/images/MainBG.jpg")));
		panel.add(lblNewLabel_2);
		
		
		setVisible(true);
	}
	
	//Check internet .if there is no internet then don't insert data 
	public boolean checkInternet()
	{
		try 
		{
				URL url = new URL("https://google.com");
				URLConnection connection = url.openConnection();
				connection.connect();
				return true;
				
	
		}
		catch (Exception e1) 
		{
			message = "Internet is not connected";
			JOptionPane.showMessageDialog(new JFrame(), message,"NO Internet",JOptionPane.ERROR_MESSAGE);
			return false;
		}
	}
	
	public static void main(String s[])
	{
		//Connect to Database 
		//DB db=new DB();
		MainClass obj = new MainClass();
		obj.setSize(908,644);
		obj.setVisible(true);
	
		
	}
}